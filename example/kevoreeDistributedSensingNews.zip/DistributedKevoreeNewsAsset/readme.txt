Introduction:

This project consists of just one Kevoree script that defines a runtime model 
corresponding to the DistributedSensingNews (Distributed) runtime configuration of NewsAssetCEP Apama project.
This apama runtime configuration declares 3 correlators and sets up connections between them. Specifically speaking,
it is the distributed version of "DistributedSensingNews (Monitor 1v2)" run configuration. Please refer to DistributedSensingNews project, which
can be found in DistibutedNewsAsset folder for more info. 
The kevoree runtime model makes use of Apama components which have been defined as Kevoree components to inject 
the monitor files, send and receive events from and to Apama correlators. Please refer to the working diagram in Diagrams folder.


Run the project:

In order to run the project, our project "DistributedKevoreeNewsAsset" must be in the same folder as the "DistributedSensingNews" project.
please be sure the import or check-out both projects, otherwise the project will not work.

After ensuring that "DistributedSensingNews" resides in the same folder as our project, we can run the project. Simply double click on
the myStart.bat file that resides in Runnable folder. This Batch file lunches the required Apama correlators and runs the kevoree 
script that instantiates the Kevoree components defining our runtime model.


Notes:
1. DistributedSensingNews Apama project must be found in the same repository wherein this project resides. 
https://svndae.eur.ad.sag/svn/sag/research/HEADS/trunk/SensingNews

2. Download Kevoree development libraries.
3. Download ApamaComponents libraries and install these in the local Maven repositories as well.