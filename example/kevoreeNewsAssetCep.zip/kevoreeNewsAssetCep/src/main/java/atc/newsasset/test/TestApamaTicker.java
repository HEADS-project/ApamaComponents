package atc.newsasset.test;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.kevoree.annotation.ComponentType;
import org.kevoree.annotation.Output;
import org.kevoree.annotation.Param;
import org.kevoree.annotation.Start;
import org.kevoree.annotation.Stop;
import org.kevoree.annotation.Update;
import org.kevoree.api.Port;

/**
 * This Kevoree component sends out messages to the Kevoree port. For 30
 * seconds, it sends out messages every second. Then the ticker is quiet for 30
 * seconds.
 * 
 * The ticker sends a JSON string, which is currently not processed in the Apama
 * application. The ticker sends two messages with different content in the form
 * of an Apama event string. The messages differ in 'Location B' and 'Location
 * C'. When the 21th message is sent, an alarm is triggered by the Apama
 * application. After the quiet period the next alarm can be send.
 */
@ComponentType(version = 3, description = "Test client which sends JSON strings to Apama correlator through ApamaComponents.")
public class TestApamaTicker {

	private String message1 = "com.softwareag.research.rest.RestJsonResponse(20,200,{\"Content-type\":\"application/json\","
			+ "\"Date\":\"Tue, 21 Jun 2016 07:28:44 GMT\","
			+ "\"Transfer-encoding\":\"chunked\"},com.softwareag.research.rest.JSONObject({\"sentiment\":\"positive\","
			+ "\"streamId\":\"GooglePlus\",\"insertionTime\":\"0\",\"keywords\":\"[]\","
			+ "\"description\":\"All you need is love but a little chocolate now and then doesn't hurt - CM. Schulz#MarliesDekkers #womenswear #womensfashion #womensclothing #dutch Ã‚Â \","
			+ "\"title\":\"All you need is love but a little chocolate now and then doesn't hurt - CM. Schulz#MarliesDekkers #womenswear #womensfashion #womensclothing #dutch Ã‚Â \","
			+ "\"reference\":\"GooglePlus#z13hsl2ijruehxvu4222tfxyzlifvdmms\",\"shares\":\"0\",\"uid\":\"GooglePlus#102815765117969522660\","
			+ "\"negativeVotes\":\"0\",\"id\":\"GooglePlus#106340594352135019688.6163572118998557218\",\"likes\":\"0\",\"original\":\"true\","
			+ "\"comments\":\"[]\",\"indexed\":\"false\",\"alethiometerUserScore\":\"0\",\"positiveVotes\":\"0\",\"numOfComments\":\"0\","
			+ "\"tags\":\"[MarliesDekkers,womenswear,womensfashion,womensclothing,dutch]\","
			+ "\"entities\":\"[com.softwareag.research.rest.JSONObject({\\\"name\\\":\\\"Location B\\\",\\\"cont\\\":\\\"0.0\\\",\\\"type\\\":\\\"LOCATION\\\"})]\","
			+ "\"publicationTime\":\"1466494124953\",\"pageUrl\":\"https://plus.google.com/102815765117969522660/posts/CX9vBM7T9i2\","
			+ "\"mediaIds\":\"[]\",\"votes\":\"[]\",\"isSearched\":\"false\"}))";

	private String message2 = "com.softwareag.research.rest.RestJsonResponse(20,200,{\"Content-type\":\"application/json\","
			+ "\"Date\":\"Tue, 21 Jun 2016 07:28:44 GMT\","
			+ "\"Transfer-encoding\":\"chunked\"},com.softwareag.research.rest.JSONObject({\"sentiment\":\"positive\","
			+ "\"streamId\":\"GooglePlus\",\"insertionTime\":\"0\",\"keywords\":\"[]\","
			+ "\"description\":\"All you need is love but a little chocolate now and then doesn't hurt - CM. Schulz#MarliesDekkers #womenswear #womensfashion #womensclothing #dutch Ã‚Â \","
			+ "\"title\":\"All you need is love but a little chocolate now and then doesn't hurt - CM. Schulz#MarliesDekkers #womenswear #womensfashion #womensclothing #dutch Ã‚Â \","
			+ "\"reference\":\"GooglePlus#z13hsl2ijruehxvu4222tfxyzlifvdmms\",\"shares\":\"0\",\"uid\":\"GooglePlus#102815765117969522660\","
			+ "\"negativeVotes\":\"0\",\"id\":\"GooglePlus#106340594352135019688.6163572118998557218\",\"likes\":\"0\",\"original\":\"true\","
			+ "\"comments\":\"[]\",\"indexed\":\"false\",\"alethiometerUserScore\":\"0\",\"positiveVotes\":\"0\",\"numOfComments\":\"0\","
			+ "\"tags\":\"[MarliesDekkers,womenswear,womensfashion,womensclothing,dutch]\","
			+ "\"entities\":\"[com.softwareag.research.rest.JSONObject({\\\"name\\\":\\\"Location C\\\",\\\"cont\\\":\\\"0.0\\\",\\\"type\\\":\\\"LOCATION\\\"})]\","
			+ "\"publicationTime\":\"1466494124953\",\"pageUrl\":\"https://plus.google.com/102815765117969522660/posts/CX9vBM7T9i2\","
			+ "\"mediaIds\":\"[]\",\"votes\":\"[]\",\"isSearched\":\"false\"}))";

	@Output
	private Port out;

	@Param(defaultValue = "2000")
	private Long delay;

	@Param(defaultValue = "1000")
	private Long period;

	private ScheduledExecutorService ser;

	@Start
	public void start() {
		ser = Executors.newSingleThreadScheduledExecutor();
		ser.scheduleAtFixedRate(new Runnable() {

			int i = 0;
			boolean sendMessages = true;
			int changeAfterNumberOfSeconds = 30;

			public void run() {

				if (sendMessages) {
					i++;
					String message = "{ \"EventTypeName\": \"Item\", \"id\":\"Twitter#621342480370388992\","
							+ "\"reference\":\"Twitter#621342481184129024\",\"streamId\":\"Twitter\","
							+ "\"title\":\"FARAGE IN DC: Blasts #Obama, Scots Nats, Cowardly #Tsipras; Says @realDonaldTrump Resonated - http://t.co/uYiqrgacPs http://t.co/w3d4JrOjuv\","
							+ "\"tags\":[\"Obama\",\"Tsipras\"],\"uid\":\"Twitter#2339238427\","
							+ "\"pageUrl\":\"http://twitter.com/BreitbartLondon/status/621342481184129024/photo/1\","
							+ "\"publicationTime\":1455651753767,\"insertionTime\":0,\"mediaIds\":[],\"sentiment\":\"positive\","
							+ "\"keywords\":[],\"entities\":[],\"original\":true,\"likes\":0,\"shares\":11,"
							+ "\"comments\":[],\"numOfComments\":0,\"isSearched\":false,\"indexed\":false,\"alethiometerUserScore\":0,"
							+ "\"positiveVotes\":0,\"negativeVotes\":0,\"votes\":[]}";
					out.send(message);
					out.send(message1);
					out.send(message2);
					// change the status ?
					sendMessages = !(i >= changeAfterNumberOfSeconds);

				} else {
					i--;
					sendMessages = !(i >= 0);
				}
			}

		}, delay, period, TimeUnit.MILLISECONDS);
	}

	@Stop
	public void stop() {
		ser.shutdown();
	}

	@Update
	public void update() {
		this.stop();
		this.start();
	}

}
