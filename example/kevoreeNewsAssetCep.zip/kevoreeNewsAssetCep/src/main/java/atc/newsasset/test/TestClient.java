/*
 * (c) Copyright 2017 Software AG. All rights reserved.
 *
 * Warning: This computer program is protected by copyright law and
 * international treaties. Unauthorized reproduction or distribution of this
 * program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted.
 */

/* $Source: $
 * $Author: $
 * $Date: $
 * $Revision: $
 */

package atc.newsasset.test;

import org.kevoree.annotation.ComponentType;
import org.kevoree.annotation.Input;
import org.kevoree.annotation.KevoreeInject;
import org.kevoree.annotation.Start;
import org.kevoree.annotation.Stop;
import org.kevoree.annotation.Update;
import org.kevoree.api.Context;
import org.kevoree.log.Log;

/**
 * TestClient
 *
 */
@ComponentType(version = 2, description = "Test receiver which receives messages from Apama correlator through Apamacomponents.")
public class TestClient {

	@KevoreeInject
	private Context context;

	@Input
	public void receiveMessage(String message) {
		if (message == null) {
			logError("message is null.", null);
		} else {
			logInfo(message);
		}
	}

	@Start
	public void start() {
		logInfo("Client started");
	}

	@Stop
	public void stop() {
		logInfo("Client stopped");
	}

	@Update
	public void update() {
		this.stop();
		this.start();
	}

	/**
	 * Log a message at ERROR level. If the Kevoree context is
	 * <code>null</code>, message is written with <code>System.out</code>.
	 * 
	 * @param message
	 *            the message to log.
	 */
	private void logError(String message, Throwable ex) {
		if (this.context == null) {
			System.out.println(message);
			ex.printStackTrace(System.out);
		} else {
			Log.error("{}: " + message + System.lineSeparator() + "{}", null, this.context.getPath(), ex.toString());
		}
	}

	/**
	 * Log a message at INFO level. If the Kevoree context is <code>null</code>,
	 * message is written with <code>System.out</code>.
	 * 
	 * @param message
	 *            the message to log.
	 */
	private void logInfo(String message) {
		if (this.context == null) {
			System.out.println(message);
		} else {
			Log.info("{}: " + message, this.context.getPath());
		}
	}

}
